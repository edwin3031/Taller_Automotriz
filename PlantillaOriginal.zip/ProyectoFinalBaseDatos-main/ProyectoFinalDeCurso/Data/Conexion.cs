﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalDeCurso.Data
{
    class Conexion
    {
        public static string conexion = "Data Source=DESKTOP-78GVLJB\\SQLSERVER; " +
                                         "Initial Catalog=Servicio_de_Mantenimiento; user=Jeison; password =Jeison.2020";
    }
}
    