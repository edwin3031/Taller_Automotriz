﻿namespace ProyectoFinalDeCurso.Reportes
{


    partial class DSMantenimientos
    {
    }
}
